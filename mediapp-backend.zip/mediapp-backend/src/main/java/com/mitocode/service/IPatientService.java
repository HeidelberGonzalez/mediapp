package com.mitocode.service;

import com.mitocode.model.Patient;

public interface IPatientService extends ICRUD<Patient, Integer>{

}
