package com.wayusoft.piachi.service.impl;

import com.wayusoft.piachi.model.MediaFile;
import com.wayusoft.piachi.model.Medic;
import com.wayusoft.piachi.repo.IfaceRepoGeneric;
import com.wayusoft.piachi.repo.IfaceRepoMediaFile;
import com.wayusoft.piachi.repo.IfaceRepoMedic;
import com.wayusoft.piachi.service.iface.IfaceServiceMediaFile;
import com.wayusoft.piachi.service.iface.IfaceServiceMedic;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ImplServiceMediaFile extends ImplServiceCRUD<MediaFile, Integer> implements IfaceServiceMediaFile {

    @Autowired
    private IfaceRepoMediaFile repo;

    @Override
    protected IfaceRepoGeneric<MediaFile, Integer> getConsultRepo() {
        return repo;
    }


}
