package com.wayusoft.piachi.repo;


import com.wayusoft.piachi.model.Consult;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.LocalDateTime;
import java.util.List;

public interface IfaceRepoConsult extends IfaceRepoGeneric<Consult, Integer> {

    //FR jaime | BD JAIME
    //FR jaime | BD Jaime
    @Query("FROM Consult c WHERE c.patient.documento = :documento OR LOWER(c.patient.nombre1) LIKE %:fullname% OR LOWER(c.patient.apellido1) LIKE %:fullname%")
    List<Consult> search(@Param("documento") String dni, @Param("fullname") String fullname);

    // >= <
    // 01-08-22 | 07-08-22
    @Query("FROM Consult c WHERE c.consultDate BETWEEN :date1 AND :date2")
    List<Consult> searchByDates(@Param("date1") LocalDateTime date1, @Param("date2") LocalDateTime date2);

    @Query(value = "select * from fn_list()", nativeQuery = true)
    List<Object[]> callProcedureOrFunction();

    //[4	"02/07/2022]"
    //[1	"22/07/2022]"
    //[11  "23/07/2022]"


}
