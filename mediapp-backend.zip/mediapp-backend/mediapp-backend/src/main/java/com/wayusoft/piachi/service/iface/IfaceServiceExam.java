package com.wayusoft.piachi.service.iface;

import com.wayusoft.piachi.model.Exam;

public interface IfaceServiceExam extends IfaceServiceCRUD<Exam, Integer>{


}
