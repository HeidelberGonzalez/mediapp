package com.wayusoft.piachi.service.iface;

import com.wayusoft.piachi.model.Patient;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

public interface IfaceServicePatient extends IfaceServiceCRUD<Patient, Integer>{

    Page<Patient> listPage(Pageable page);

}
