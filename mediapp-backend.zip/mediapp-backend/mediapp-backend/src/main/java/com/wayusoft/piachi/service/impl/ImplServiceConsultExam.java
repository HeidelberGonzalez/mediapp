package com.wayusoft.piachi.service.impl;

import com.wayusoft.piachi.model.ConsultExam;
import com.wayusoft.piachi.repo.IfaceRepoConsultExam;
import com.wayusoft.piachi.service.iface.IfaceServiceConsultExam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ImplServiceConsultExam implements IfaceServiceConsultExam {

    @Autowired
    private IfaceRepoConsultExam repo;


    @Override
    public List<ConsultExam> getExamsByConsultId(Integer idConsult) {
        return repo.getExamsByConsultId(idConsult);
    }
}
