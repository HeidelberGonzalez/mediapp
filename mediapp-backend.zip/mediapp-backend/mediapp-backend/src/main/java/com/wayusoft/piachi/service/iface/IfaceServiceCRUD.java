package com.wayusoft.piachi.service.iface;

import java.util.List;

public interface IfaceServiceCRUD<T, ID> {

    T save(T t);
    T update(T t);
    T findById(ID id);
    List<T> findAll();
    void delete(ID id);
}
