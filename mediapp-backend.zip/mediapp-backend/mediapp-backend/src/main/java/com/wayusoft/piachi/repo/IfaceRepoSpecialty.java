package com.wayusoft.piachi.repo;


import com.wayusoft.piachi.model.Specialty;

public interface IfaceRepoSpecialty extends IfaceRepoGeneric<Specialty, Integer> {


}
