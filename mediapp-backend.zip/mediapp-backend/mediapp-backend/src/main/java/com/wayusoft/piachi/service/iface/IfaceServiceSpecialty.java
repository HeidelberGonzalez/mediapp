package com.wayusoft.piachi.service.iface;


import com.wayusoft.piachi.model.Specialty;

public interface IfaceServiceSpecialty extends IfaceServiceCRUD<Specialty, Integer>{


}
