package com.wayusoft.piachi.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Size;
import java.time.LocalDate;


// Clase de apoyo la cual permite halla diferencia entre la estructura de los datos enviados por el cliente desde el frontend y las entidades de bases de
// de datos, por ejemplo retirar algun campo sin que el cliente se entere
@Data
@AllArgsConstructor
@NoArgsConstructor
public class PatientDTO {

    private Integer idUs;

    @NotEmpty
    @Size(min = 2, message = "{tipdoc.size}")
    private String tipdoc;
    @NotEmpty
    @Size(min = 8,max = 12,message = "{doc.size}")
    private String documento;
    private String codeps;
    private Integer tipUsu;
    @NotEmpty
    @Size(min = 2, message = "Apellido1 is required")
    private String apellido1;
    private String apellido2;
    @NotEmpty
    @Size(min = 2, message = "Nombre1 is required")
    private String nombre1;
    private String nombre2;
    private LocalDate fecnac;
    private Integer edad;
    private Integer uniedad;
    private String sexo;
    private String coddept;
    private String codmunc;
    private String zona;
    private String estd;
    private String direccion;
    private String telefono;
    private String email;
}
