package com.wayusoft.piachi.model;

import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.time.LocalDate;

@Entity
@Data
@NoArgsConstructor
public class Patient {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_us", nullable = false)
    private Integer idUs;
    @Column(name = "tipdoc", nullable = false, length = 2)
    private String tipdoc;
    @Column(name = "documento", nullable = false, length = 40)
    private String documento;
    @Column(name = "codeps", length = 10)
    private String codeps;
    @Column(name = "tip_usu", length = 1)
    private Integer tipUsu;
    @Column(name = "apellido1", length = 50)
    private String apellido1;
    @Column(name = "apellido2", length = 50)
    private String apellido2;
    @Column(name = "nombre1", length = 50)
    private String nombre1;
    @Column(name = "nombre2", length = 50)
    private String nombre2;
    @Column(name = "fecnac")
    private LocalDate fecnac;
    @Column(name = "edad",length = 1)
    private Integer edad;
    @Column(name = "uniedad",length = 1)
    private Integer uniedad;
    @Column(name = "sexo",length = 1)
    private String sexo;
    @Column(name = "coddept",length = 3)
    private String coddept;
    @Column(name = "codmunc", length = 3)
    private String codmunc;
    @Column(name = "zona",length = 1)
    private String zona;
    @Column(name = "estd",length = 12)
    private String estd;
    @Column(length = 150, nullable = true)
    private String direccion;

    @Column(length = 40, nullable = false)
    private String telefono;

    @Column(length = 55, nullable = false)
    private String email;
}
