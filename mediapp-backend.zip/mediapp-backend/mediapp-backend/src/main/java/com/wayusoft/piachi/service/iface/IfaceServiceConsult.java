package com.wayusoft.piachi.service.iface;


import com.wayusoft.piachi.dto.ConsultProcDTO;
import com.wayusoft.piachi.model.Consult;
import com.wayusoft.piachi.model.Exam;

import java.time.LocalDateTime;
import java.util.List;

public interface IfaceServiceConsult extends IfaceServiceCRUD<Consult, Integer>{

  Consult saveTransactional(Consult consult, List<Exam> exams);

  List<Consult> search(String documento, String fullname);
  List<Consult> searchByDates(LocalDateTime date1, LocalDateTime date2);

  List<ConsultProcDTO> callProcedureOrFunction();

  byte[] generateReport() throws Exception;

}
