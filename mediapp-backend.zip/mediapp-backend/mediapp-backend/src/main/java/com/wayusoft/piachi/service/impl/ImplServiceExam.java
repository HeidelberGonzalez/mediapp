package com.wayusoft.piachi.service.impl;

import com.wayusoft.piachi.model.Exam;
import com.wayusoft.piachi.repo.IfaceRepoExam;
import com.wayusoft.piachi.repo.IfaceRepoGeneric;
import com.wayusoft.piachi.service.iface.IfaceServiceExam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ImplServiceExam extends ImplServiceCRUD<Exam, Integer> implements IfaceServiceExam {

    @Autowired
    private IfaceRepoExam repo;

    @Override
    protected IfaceRepoGeneric<Exam, Integer> getConsultRepo() {
        return repo;
    }


}
