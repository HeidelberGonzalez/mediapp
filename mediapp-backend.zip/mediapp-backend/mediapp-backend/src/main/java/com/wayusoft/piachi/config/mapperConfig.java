package com.wayusoft.piachi.config;

import org.modelmapper.ModelMapper;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;


//Clase que permite utilizar singleton para poder aprovechar las instacias en springBoot
@Configuration
public class mapperConfig {

    @Bean
    public ModelMapper modelMapper(){

        return new ModelMapper();
    }
}
