package com.wayusoft.piachi.repo;

import com.wayusoft.piachi.model.MediaFile;


public interface IfaceRepoMediaFile extends IfaceRepoGeneric<MediaFile, Integer> {


}
