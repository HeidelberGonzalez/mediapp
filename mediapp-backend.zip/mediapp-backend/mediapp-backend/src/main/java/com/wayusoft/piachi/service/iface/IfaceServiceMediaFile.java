package com.wayusoft.piachi.service.iface;


import com.wayusoft.piachi.model.MediaFile;

public interface IfaceServiceMediaFile extends IfaceServiceCRUD<MediaFile, Integer>{


}
