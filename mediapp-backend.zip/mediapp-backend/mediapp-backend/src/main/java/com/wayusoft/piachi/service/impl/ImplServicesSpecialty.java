package com.wayusoft.piachi.service.impl;

import com.wayusoft.piachi.model.Exam;
import com.wayusoft.piachi.model.Specialty;
import com.wayusoft.piachi.repo.IfaceRepoExam;
import com.wayusoft.piachi.repo.IfaceRepoGeneric;
import com.wayusoft.piachi.repo.IfaceRepoSpecialty;
import com.wayusoft.piachi.service.iface.IfaceServiceExam;
import com.wayusoft.piachi.service.iface.IfaceServiceSpecialty;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ImplServicesSpecialty extends ImplServiceCRUD<Specialty, Integer> implements IfaceServiceSpecialty {

    @Autowired
    private IfaceRepoSpecialty repo;

    @Override
    protected IfaceRepoGeneric<Specialty, Integer> getConsultRepo() {
        return repo;
    }


}
