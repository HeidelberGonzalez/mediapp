package com.wayusoft.piachi.repo;

import com.wayusoft.piachi.model.Patient;

public interface IfaceRepoPatient extends IfaceRepoGeneric<Patient, Integer> {


}
