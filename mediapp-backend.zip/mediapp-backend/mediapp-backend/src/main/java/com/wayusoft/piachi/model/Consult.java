package com.wayusoft.piachi.model;


import lombok.*;

import javax.persistence.*;
import java.time.LocalDateTime;
import java.util.List;


@Getter
@Setter
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
@NoArgsConstructor
@AllArgsConstructor
@Entity
public class Consult {

    @EqualsAndHashCode.Include
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer idConsult;

    @ManyToOne
    @JoinColumn(name = "id_patient", nullable = false, foreignKey = @ForeignKey( name = "FK_CONSULT_PATIENT"))
    private Patient patient;

    @ManyToOne
    @JoinColumn(name = "id_medic", nullable = false, foreignKey = @ForeignKey( name = "FK_CONSULT_MEDIC"))
    private Medic medic;


    @ManyToOne
    @JoinColumn(name = "id_specialitty", nullable = false, foreignKey = @ForeignKey( name = "FK_CONSULT_SPECIALITY"))
    private Specialty specialty;

    @Column(length = 3, nullable = false)
    private String numConsult;

    @Column(nullable = false)
    private LocalDateTime consultDate;

    @OneToMany(mappedBy = "consult",cascade = { CascadeType.ALL }, orphanRemoval = true, fetch = FetchType.LAZY)
    private List<ConsultDetails> details;
}
