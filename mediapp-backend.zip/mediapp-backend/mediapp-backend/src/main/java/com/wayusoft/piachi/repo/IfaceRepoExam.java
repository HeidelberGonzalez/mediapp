package com.wayusoft.piachi.repo;

import com.wayusoft.piachi.model.Exam;

public interface IfaceRepoExam extends IfaceRepoGeneric<Exam, Integer> {


}
