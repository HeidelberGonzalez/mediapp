package com.wayusoft.piachi.service.impl;

import com.wayusoft.piachi.repo.IfaceRepoGeneric;
import com.wayusoft.piachi.service.iface.IfaceServiceCRUD;

import java.util.List;

public abstract class ImplServiceCRUD<T,ID> implements IfaceServiceCRUD<T, ID> {

    protected abstract IfaceRepoGeneric<T, ID> getConsultRepo();
    @Override
    public T save(T t) {
        return getConsultRepo().save(t);
    }

    @Override
    public T update(T t) {
        return getConsultRepo().save(t);
    }

    @Override
    public T findById(ID id) {
        return getConsultRepo().findById(id).orElse( null );
    }

    @Override
    public List<T> findAll() {
        return getConsultRepo().findAll();
    }

    @Override
    public void delete(ID id) {
        getConsultRepo().deleteById(id);
    }
}
