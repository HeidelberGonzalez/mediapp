package com.wayusoft.piachi.service.impl;

import com.wayusoft.piachi.model.Medic;
import com.wayusoft.piachi.repo.IfaceRepoGeneric;
import com.wayusoft.piachi.repo.IfaceRepoMedic;
import com.wayusoft.piachi.service.iface.IfaceServiceMedic;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ImplServiceMedic extends ImplServiceCRUD<Medic, Integer> implements IfaceServiceMedic {

    @Autowired
    private IfaceRepoMedic repo;

    @Override
    protected IfaceRepoGeneric<Medic, Integer> getConsultRepo() {
        return repo;
    }


}
