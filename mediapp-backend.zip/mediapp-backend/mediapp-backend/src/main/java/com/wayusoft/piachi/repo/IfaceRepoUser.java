package com.wayusoft.piachi.repo;


import com.wayusoft.piachi.model.User;

public interface IfaceRepoUser extends IfaceRepoGeneric<User, Integer>  {

    //from user where username = ?
    //Derived Query
    User findOneByUsername(String username);
}