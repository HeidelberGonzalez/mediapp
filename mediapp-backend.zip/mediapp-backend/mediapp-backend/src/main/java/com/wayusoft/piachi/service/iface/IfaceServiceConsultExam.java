package com.wayusoft.piachi.service.iface;

import com.wayusoft.piachi.model.ConsultExam;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface IfaceServiceConsultExam {

    List<ConsultExam> getExamsByConsultId(@Param("idConsult") Integer idConsult);

}
