package com.wayusoft.piachi.service.impl;

import com.wayusoft.piachi.model.Patient;
import com.wayusoft.piachi.repo.IfaceRepoGeneric;
import com.wayusoft.piachi.repo.IfaceRepoPatient;
import com.wayusoft.piachi.service.iface.IfaceServicePatient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

@Service
public class ImplServicePatient extends ImplServiceCRUD <Patient, Integer> implements IfaceServicePatient{

    @Autowired
    private IfaceRepoPatient repo;

    @Override
    protected IfaceRepoGeneric<Patient, Integer> getConsultRepo() {
        return repo;
    }

    @Override
    public Page<Patient> listPage(Pageable page) {
        return repo.findAll(page);
    }
}
