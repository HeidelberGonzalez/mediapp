package com.wayusoft.piachi.repo;

import com.wayusoft.piachi.model.Medic;

public interface IfaceRepoMedic extends IfaceRepoGeneric<Medic, Integer> {


}
