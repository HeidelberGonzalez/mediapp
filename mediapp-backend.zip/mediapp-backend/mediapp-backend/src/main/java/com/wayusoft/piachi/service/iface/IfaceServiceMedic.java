package com.wayusoft.piachi.service.iface;

import com.wayusoft.piachi.model.Medic;

public interface IfaceServiceMedic extends IfaceServiceCRUD<Medic, Integer>{


}
