export class Medic{
    idMedic: number;
    firstName: string;
    lastName: string;
    cmd: string;
    photoUrl: string;
}