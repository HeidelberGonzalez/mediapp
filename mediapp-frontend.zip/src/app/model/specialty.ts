export class Specialty {
    idSpecialitty: number;
    name: string;
    description: string
}