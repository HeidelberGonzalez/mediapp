export class Exam {
    idExam: number;
    name: string;
    description: string
}