export class Patient {
    idUs: number;
    tipdoc: string;
    documento: string;
    codeps: string;
    tipUsu: string;
    apellido1: string;
    apellido2: string;
    nombre1: string;
    nombre2: string;
    fecnac: string;
    edad: string;
    uniedad: string;
    sexo: string;
    coddept: string;
    codmunc: string;
    zona: string;
    estd: string;
    direccion: string;
    telefono: string;
    email: string;
}