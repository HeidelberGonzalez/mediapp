export class FilterConsultDTO{
    
    constructor(public documento: string, public fullname: string){}
    /*
    dni: string;
    fullname: string;

    constructor(dni: string, fullname: string){
        this.dni = dni;
        this.fullname = fullname;
    }*/
}