import { Consult } from "../model/consult";
import { Exam } from "../model/exam";

export class ConsultListExamDTO{
    consult: Consult;
    lstExam: Exam[];
  }
  