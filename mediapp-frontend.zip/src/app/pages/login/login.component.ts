import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { LoginService } from '../../service/login.service';
import { environment } from '../../../environments/environment.development';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  username: string;
  password: string;
  message: string;
  error: string;

  constructor(
    private loginService: LoginService,
    //private router: Router
  ) { }

  ngOnInit(): void {
  }

  /*Para cargar archivo login-animation.ja pero hasta ahora es complicado cargar la carpeta asset
  ngAfterViewInit() {
    (window as any).initialize();
  }*/

  login(){
    
    this.loginService.login(this.username, this.password).subscribe(data => {
      sessionStorage.setItem(environment.TOKEN_NAME, data.access_token);
      console.log(sessionStorage.getItem(environment.TOKEN_NAME));
      //this.router.navigate(['/pages/dashboard']);
    });
  }

}
