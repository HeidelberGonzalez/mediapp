import { Component, OnInit, ViewChild } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { FilterConsultDTO } from '../../dto/filterConsultDTO';
import { MatTabGroup } from '@angular/material/tabs';
import { ConsultService } from '../../service/consult.service';
import { Consult } from '../../model/consult';
import { MatTableDataSource } from '@angular/material/table';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import moment from 'moment';
import { MatDialog } from '@angular/material/dialog';
import { SearchDialogComponent } from './search-dialog/search-dialog.component';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrl: './search.component.css'
})
export class SearchComponent implements OnInit {

  displayedColumns = ['patient', 'medic', 'specialty', 'date', 'actions'];
  dataSource: MatTableDataSource<Consult>;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;


  form: FormGroup;
  maxEnd: Date = new Date();
  @ViewChild('tab') tabGroup: MatTabGroup;

  constructor(
    private dialog: MatDialog,
    private consultService: ConsultService
  ) { }


  ngOnInit(): void {
    this.form = new FormGroup({
      'documento': new FormControl(),
      'fullname': new FormControl(),
      'startDate': new FormControl(),
      'endDate': new FormControl()
    });
  }

  search() {

    if (this.tabGroup.selectedIndex == 0) {

      let documento = this.form.value['documento'];
      let fullname = this.form.value['fullname'];
      let dto = new FilterConsultDTO(documento, fullname);

      if (dto.documento == null) {
        delete dto.documento;
      }

      if (dto.fullname == null) {
        delete dto.fullname;
      }

      this.consultService.searchOthers(dto).subscribe(data => this.createTable(data))

      console.log(dto);

    } else {

      let date1 = this.form.value['startDate'];
      let date2 = this.form.value['endDate'];

      date1 = moment(date1).format('YYYY-MM-DDTHH:mm:ss');
      date2 = moment(date2).format('YYYY-MM-DDTHH:mm:ss');

      this.consultService.searchByDates(date1, date2).subscribe(data => this.createTable(data))

    }



  }

  createTable(data: Consult[]) {
    this.dataSource = new MatTableDataSource(data);
    this.dataSource.sort = this.sort;
    this.dataSource.paginator = this.paginator;
  }
  

  viewDetails(consult: Consult) {
     this.dialog.open(SearchDialogComponent, {
       width: '750px',
       data: consult
     })
  }
}
