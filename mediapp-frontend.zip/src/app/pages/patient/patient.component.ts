import { Component, OnInit, ViewChild } from '@angular/core';
import { PatientService } from '../../service/patient.service';
import { Patient } from './../../model/patient';
import { MatTableDataSource } from '@angular/material/table';
import { MatSnackBar } from '@angular/material/snack-bar';
import { switchMap } from 'rxjs';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';

@Component({
  selector: 'app-patient',
  templateUrl: './patient.component.html',
  styleUrl: './patient.component.css'
})
export class PatientComponent implements OnInit {

  
  displayedColumns: string[] = ['id', 'tipDoc', 'doc', 'primerNom', 'primerApe', 'actions'];
  dataSource: MatTableDataSource<Patient>;
  //Para obtener control elementos de la vista html
  @ViewChild('paginador') paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  totalElements: number;

  constructor(
    private snackBar: MatSnackBar,
    private patientService: PatientService) { }
 

  ngOnInit(): void {
    //Proceso Asyncrono que se ejecuta cuando a la variable reactiva del service se le aplica un .next
    // se llama a la variable reactiva del service y se trabaja con un .suscribe()
    this.patientService.patientChange.subscribe(data => {
      //Carga los datos en la tabla
      this.createTable(data);
    });

    this.patientService.getMessageChange().subscribe(data => {
      this.snackBar.open(data, 'INFO', { duration: 2000, verticalPosition: "top", horizontalPosition: "right" });
    });

    this.patientService.listPageable(0, 10).subscribe(data => {
      this.createTable(data);
    });

    /*this.patientService.findAll().subscribe(data => {
      this.createTable(data);
    });

    //Se llama al .findAll() del service y se usa .suscribe para cargar los datos en la tabla
    this.patientService.findAll().subscribe(data => {
      this.createTable(data);
    });*/
  }

  applyFilter(e: any){
    this.dataSource.filter = e.target.value.trim().toLowerCase();
  }

  delete(idPatient: number){
    this.patientService.delete(idPatient).pipe(switchMap( ()=> {
      return this.patientService.findAll();
    }))
    .subscribe(data => {
      this.patientService.patientChange.next(data);
      this.patientService.setMessageChange('DELETED!');
    })
    ;
  }

  createTable(patients: any){
    this.dataSource = new MatTableDataSource(patients.content);
    this.totalElements = patients.totalElements;

    /*
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;    */
  }

  showMore(e: any){
    this.patientService.listPageable(e.pageIndex, e.pageSize).subscribe(data => this.createTable(data));
  }

}
