import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { PatientService } from '../../../service/patient.service';
import { ActivatedRoute, Router } from '@angular/router';
import { Patient } from './../../../model/patient';
import { switchMap } from 'rxjs';

@Component({
  selector: 'app-patient-edit',
  templateUrl: './patient-edit.component.html',
  styleUrl: './patient-edit.component.css'
})
export class PatientEditComponent implements OnInit{

  id: number;
  isEdit: boolean;
  form: FormGroup;

  constructor(
    private route: ActivatedRoute, //Permite conocer la URL activa a ese momento
    private router: Router,  //Permit navegar entre componets
    private patientService: PatientService) {
    
  }

  ngOnInit(): void {
    this.form = new FormGroup({
      'idPatient' : new FormControl(0),
      'firstName' : new FormControl('', [Validators.required, Validators.minLength(3)]),
      'lastName' : new FormControl('', [Validators.required, Validators.minLength(3)]),
      'tipdni' : new FormControl('', [Validators.required, Validators.minLength(2)]),
      'dni' : new FormControl('', [Validators.required, Validators.minLength(8)]),
      'address' : new FormControl(''),
      'phone' : new FormControl('', [Validators.required, Validators.minLength(9)]),
      'email' : new FormControl('', [Validators.required, Validators.email])
    });

    //Determina si es una llamada para UPDATE o INSERT
    this.route.params.subscribe(data => {
      this.id = data['id'];
      this.isEdit = data['id'] != null;
      this.initForm();
    })
  }

  initForm(){
    if(this.isEdit){
      //Llama al metodo .findById(this.id) del service y carga el objeto this.form con los datos a mostrar 
      this.patientService.findById(this.id).subscribe(data => {
        this.form = new FormGroup({
          'idPatient' : new FormControl(data.idUs),
          'firstName' : new FormControl(data.nombre1, [Validators.required, Validators.minLength(3)]),
          'lastName' : new FormControl(data.apellido1, [Validators.required, Validators.minLength(3)]),
          'tipdni' : new FormControl(data.tipdoc, [Validators.required, Validators.minLength(2)]),
          'dni' : new FormControl(data.documento, [Validators.required, Validators.maxLength(8)]),
          'address' : new FormControl(data.direccion),
          'phone' : new FormControl(data.telefono, [Validators.required, Validators.minLength(9)]),
          'email' : new FormControl(data.email, [Validators.required, Validators.email])
        });
      });      
    }
  }
  //Metodo de lectura que solo devuelve como acceder a los atributos del formulario
  get f(){
    return this.form.controls;
  }

  operate(){
    //Primero determina si el el formulario es valido de acuerdo a los campos requeridos
    //Si caso tal el formulario es invalido llega hasta aqui y retorna
    if (this.form.invalid) { return; } 

    //Recupera todo los datos del formulario html
    //Utizando un objeto patient el cual sera enviado al backend ya sea para actualizar o crear un registro nuevo
    let patient = new Patient();
    patient.idUs = this.form.value['idPatient'];
    patient.apellido1 = this.form.value['lastName'];
    patient.nombre1 = this.form.value['firstName'];
    patient.tipdoc = this.form.value['tipdni'];
    patient.documento = this.form.value['dni'];
    patient.direccion = this.form.value['address'];
    patient.telefono = this.form.value['phone'];
    patient.email = this.form.value['email'];


    //Se de termina y es un UPDATE o un INsert
    if (this.isEdit) {
      //UPDATE
      //Practica COMUN del uso de la variable reactiva declarada en el Service 
      // Anida varios .suscribe NO SE RECOMIENDA
      this.patientService.update(patient).subscribe(     //  .subscribe() es el encargado de ejecutar la accion a realizar
        () => {
        this.patientService.findAll().subscribe(data => {  //Llama nuevamente al metodo findAll() del service y al estar suscrito puede obtener una data nueva
          //.next le indica a la varible reactiva que ha sido modoficada y en el metodo OnInit del padre se recarga la tabla
          this.patientService.patientChange.next(data); 
          this.patientService.setMessageChange('UPDATED!')
        });
      });
    } else {  
      //INSERT
      //Practica IDEAL del uso de la variable reactiva declarada en patientService 
      // Se usa un operador .pipe ya que el proceso anterior devuelve un observible
      // y permite concatenar otros operadores reactivos tal como switchMap
      this.patientService.save(patient).pipe(switchMap(()=>{        
        return this.patientService.findAll();
      }))
      .subscribe(data => {
        this.patientService.patientChange.next(data);
        this.patientService.setMessageChange('CREATED!')
      });
    }
    //Al ralizar la accion ya sea UDATE o INSERT navega a la ruta indicada
    this.router.navigate(['/pages/patient']);
  }

}
