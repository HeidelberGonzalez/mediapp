import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { ExamService } from '../../../service/exam.service';
import { Exam } from '../../../model/exam';
import { switchMap } from 'rxjs';

@Component({
  selector: 'app-exam-edit',
  templateUrl: './exam-edit.component.html',
  styleUrl: './exam-edit.component.css'
})
export class ExamEditComponent implements OnInit {

  
  id: number;
  isEdit: boolean;
  form: FormGroup;

  
  constructor(
    private route: ActivatedRoute, //Permite conocer la URL activa a ese momento
    private router: Router,  //Permit navegar entre componets
    private examService: ExamService) {
    
  }


  ngOnInit(): void {
    this.form = new FormGroup({
      'idExam' : new FormControl(0),
      'name' : new FormControl('', [Validators.required, Validators.minLength(3)]),
      'description' : new FormControl('', [Validators.required, Validators.minLength(3)])
    });

    //Determina si es una llamada para UPDATE o INSERT
    this.route.params.subscribe(data => {
      this.id = data['id'];
      this.isEdit = data['id'] != null;
      this.initForm();
    })
  }

  initForm(){
    if(this.isEdit){
      //Llama al metodo .findById(this.id) del service y carga el objeto this.form con los datos a mostrar 
      this.examService.findById(this.id).subscribe(data => {
        this.form = new FormGroup({
          'idExam' : new FormControl(data.idExam),
          'name' : new FormControl(data.name, [Validators.required, Validators.minLength(3)]),
          'description' : new FormControl(data.description, [Validators.required, Validators.minLength(3)])
        });
      });      
    }
  }
  //Metodo de lectura que solo devuelve como acceder a los atributos del formulario
  get f(){
    return this.form.controls;
  }

  operate(){
    //Primero determina si el el formulario es valido de acuerdo a los campos requeridos
    //Si caso tal el formulario es invalido llega hasta aqui y retorna
    if (this.form.invalid) { return; } 

    //Recupera todo los datos del formulario html
    //Utizando un objeto exam el cual sera enviado al backend ya sea para actualizar o crear un registro nuevo
    let exam = new Exam();
    exam.idExam = this.form.value['idExam'];
    exam.name = this.form.value['name'];
    exam.description = this.form.value['description'];


    //Se de termina y es un UPDATE o un INsert
    if (this.isEdit) {
      //UPDATE
      //Practica COMUN del uso de la variable reactiva declarada en el Service 
      // Anida varios .suscribe NO SE RECOMIENDA
      this.examService.update(exam).subscribe(     //  .subscribe() es el encargado de ejecutar la accion a realizar
        () => {
        this.examService.findAll().subscribe(data => {  //Llama nuevamente al metodo findAll() del service y al estar suscrito puede obtener una data nueva
          //.next le indica a la varible reactiva que ha sido modoficada y en el metodo OnInit del padre se recarga la tabla
          this.examService.setExamChange(data); 
          this.examService.setMessageChange('UPDATED!')
        });
      });
    } else {  
      //INSERT
      //Practica IDEAL del uso de la variable reactiva declarada en examService 
      // Se usa un operador .pipe ya que el proceso anterior devuelve un observible
      // y permite concatenar otros operadores reactivos tal como switchMap
      this.examService.save(exam).pipe(switchMap(()=>{        
        return this.examService.findAll();
      }))
      .subscribe(data => {
        this.examService.setExamChange(data);
        this.examService.setMessageChange('CREATED!')
      });
    }
    //Al ralizar la accion ya sea UDATE o INSERT navega a la ruta indicada
    this.router.navigate(['/pages/exam']);
  }
}
