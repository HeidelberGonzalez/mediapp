import { Component, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { Exam } from '../../../model/exam';
import { ExamService } from '../../../service/exam.service';
import { switchMap } from 'rxjs';

@Component({
  selector: 'app-exam-dialog',
  templateUrl: './exam-dialog.component.html',
  styleUrl: './exam-dialog.component.css'
})
export class ExamDialogComponent {

  exam: Exam;

  constructor(
    @Inject(MAT_DIALOG_DATA) private data: Exam,
    private dialogRef: MatDialogRef<ExamDialogComponent>,
    private examService: ExamService
  ){}
  ngOnInit(): void {
    this.exam = { ...this.data };
  }
  operate() {
    if(this.exam != null && this.exam.idExam >0 ){
      //UPDATE
      this.examService.update(this.exam).pipe(switchMap(()=>{
        return this.examService.findAll();
      }))
      .subscribe(data => {
        this.examService.setExamChange(data);
        this.examService.setMessageChange('UPDATED!');
      });/**/
    }else{
      //SAVE
      this.examService.save(this.exam).pipe(switchMap(()=>{
        return this.examService.findAll();
      }))
      .subscribe(data => {
        this.examService.setExamChange(data);
        this.examService.setMessageChange('CREATED!');
      });
    }
    this.close();
  }

  close() {
    this.dialogRef.close();
  }
}
