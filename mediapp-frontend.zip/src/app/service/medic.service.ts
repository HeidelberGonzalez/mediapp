import { Injectable } from '@angular/core';
import { GenericService } from './generic.service';
import { Medic } from '../model/medic';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../environments/environment.development';
import { Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class MedicService  extends GenericService<Medic> {

  private medicChange = new Subject<Medic[]>;
  private messageChange = new Subject<string>;

  constructor(protected override http: HttpClient) { 
    super(
      http,
      `${environment.HOST}/medics`
      );
  }

    //////////get set/////////////
    setMedicChange(list: Medic[]){
      this.medicChange.next(list);
    }
  
    getMedicChange(){
      return this.medicChange.asObservable();
    } 
  
    setMessageChange(message: string){
      this.messageChange.next(message);
    }
  
    getMessageChange(){
      return this.messageChange.asObservable();
    }
}
