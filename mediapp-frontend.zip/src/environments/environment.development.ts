export const environment = {

    production: false,
    HOST: 'http://localhost:9889',
    TOKEN_AUTH_USERNAME: 'mitomediapp',
    TOKEN_AUTH_PASSWORD: 'mito89codex',
    TOKEN_NAME: 'token'
};
