import {
  MatDivider,
  MatDividerModule
} from "./chunk-N73YYJVK.js";
import "./chunk-6SXWA4SO.js";
import "./chunk-QT4EXI5E.js";
import "./chunk-NZUHDJDD.js";
import "./chunk-2O67VFJ4.js";
import "./chunk-PUFHKYRY.js";
import "./chunk-WSA2QMXP.js";
import "./chunk-PZQZAEDH.js";
export {
  MatDivider,
  MatDividerModule
};
//# sourceMappingURL=@angular_material_divider.js.map
