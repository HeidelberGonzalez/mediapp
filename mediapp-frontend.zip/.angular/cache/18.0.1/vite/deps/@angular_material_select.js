import {
  MAT_SELECT_CONFIG,
  MAT_SELECT_SCROLL_STRATEGY,
  MAT_SELECT_SCROLL_STRATEGY_PROVIDER,
  MAT_SELECT_SCROLL_STRATEGY_PROVIDER_FACTORY,
  MAT_SELECT_TRIGGER,
  MatSelect,
  MatSelectChange,
  MatSelectModule,
  MatSelectTrigger,
  matSelectAnimations
} from "./chunk-XYQKQQTB.js";
import "./chunk-KZH7B62U.js";
import "./chunk-IKTQ6A73.js";
import "./chunk-RKBAW67Z.js";
import "./chunk-YR37TOCC.js";
import "./chunk-M2BIOEGP.js";
import {
  MatError,
  MatFormField,
  MatHint,
  MatLabel,
  MatPrefix,
  MatSuffix
} from "./chunk-YZVEACW6.js";
import "./chunk-OXI7RCJH.js";
import "./chunk-RO7JBPK7.js";
import {
  MatOptgroup,
  MatOption
} from "./chunk-6SXWA4SO.js";
import "./chunk-QT4EXI5E.js";
import "./chunk-NZUHDJDD.js";
import "./chunk-2O67VFJ4.js";
import "./chunk-PUFHKYRY.js";
import "./chunk-WSA2QMXP.js";
import "./chunk-PZQZAEDH.js";
export {
  MAT_SELECT_CONFIG,
  MAT_SELECT_SCROLL_STRATEGY,
  MAT_SELECT_SCROLL_STRATEGY_PROVIDER,
  MAT_SELECT_SCROLL_STRATEGY_PROVIDER_FACTORY,
  MAT_SELECT_TRIGGER,
  MatError,
  MatFormField,
  MatHint,
  MatLabel,
  MatOptgroup,
  MatOption,
  MatPrefix,
  MatSelect,
  MatSelectChange,
  MatSelectModule,
  MatSelectTrigger,
  MatSuffix,
  matSelectAnimations
};
//# sourceMappingURL=@angular_material_select.js.map
